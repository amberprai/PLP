import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Order, Book, OrderedBook } from '../class/order';
import { OrderDetail } from 'src/app/order-detail';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
 


  orders: Order[];
  orderDetails: OrderDetail[];
  Bookid=0;

  url1: string = "http://localhost:4000";
  constructor(private http: HttpClient) {
    this.getOrder().subscribe(data => this.orders = data);
  }
  getOrder(): Observable<Order[]> {

    return this.http.get<Order[]>(this.url1);
  }
  getData() {
    return this.orders;
  }
  setOrder(orders: Order[]) {
    this.orders = orders;
  }
  public getOrderList() {
    return this.http.get<Order[]>(this.url1+"/adminOrderList");
  }
  
  deleteOrder(list: Order) {
    console.log(list);
    return this.http.delete<Order[]>(this.url1 + "/delete/" + list.id);
  }

  getOrderById(id:number){
    console.log(id);
    return this.http.get<Order>(this.url1+"/getorder/"+id);
    this.Bookid=id;
  }

  editOrder(order:Order)
  {
    console.log(order);
    return this.http.put(this.url1+"/edit/"+order.id,order);
  }
  getBooks() {
   return this.http.get<Book>(this.url1+"/order/"+ this.Bookid);
  }
  getOrderedBooks() {
   return this.http.get<OrderedBook>(this.url1+"/order/"+this.Bookid)
  }
}