import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from 'src/app/order/order.service';
import { Orderhistory } from 'src/app/orderhistory';
import { CustomerShipping } from 'src/app/customer-shipping';
import { Router } from '@angular/router';
import { AdminService } from '../../backend/service/admin.service';
import { Order } from '../../backend/class/order';

@Component({
  selector: 'app-order-detail',
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.css']
})
export class OrderDetailComponent implements OnInit {
 bookDetails:Orderhistory[];
 book:Orderhistory;
 customerDetail:CustomerShipping[];
 order:Order[];

  constructor(private adminOrderService:AdminService,private router:Router) { }

  ngOnInit() {
   
    this.adminOrderService.getOrderList().subscribe(data =>{this.order=data})
    }
    
    
  }

