import { Component, OnInit } from '@angular/core';

import { OrderServiceService } from '../../order.service';
import { OrderDetail } from 'src/app/order-detail';
import { Order } from '../../backend/class/order';
import { AdminService } from '../../backend/service/admin.service';


@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orders:Order[];
  order:OrderDetail;

  constructor(private adminOrderService:AdminService) { }

  ngOnInit() {
    if(!this.adminOrderService.getData()){
      this.adminOrderService.getOrder().subscribe(data=>{
        this.orders=data;
        this.adminOrderService.setOrder(this.orders);
      });
    }
    
  }

}
