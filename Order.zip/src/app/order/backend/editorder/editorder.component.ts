import { Component, OnInit } from '@angular/core';
import { Order, Book, OrderedBook, Category, Review, Customer } from '../class/order';
import { AdminService } from '../service/admin.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {

  order: Order[];
 category: Category = { "id": 0, "categoryName": "" };
  review: Review = { "id": 0, "headline": "", "customerName": "", "comments": "", "bookTitle": "", "reviewDate": "", "rating": 0 };
  orders: Order;
  books: OrderedBook[];
  customer: Customer;
  book: Book[];
  //={"id":0,
  //"book":{"author":'',"bookImage":'',"category":this.category,"description":'',"id":0,"isbn":'',"price":0,"purchaseDate":'',"reviews":this.review,"title":''},
  //"customer":{"id":0,"fullname":'',"email":'',"country":'',"city":'',"address":'',"zipcode":'',"registerDate":'',"phonenumber":'',"password":'',"orders":this.orders},
  //"orderDate":'',"orderedBy":'',"paymentMethod":'',"recipientName":'',"recipientPhone":'',"shipto":'',"status":''};


  constructor(private adminService: AdminService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.adminService.getOrderById(params['id'])
        .subscribe((result) => {
          console.log(result); this.orders = result;
          console.log(this.orders.books[1].book.author);
          console.log(this.orders.books[1].book.title)
          console.log(this.orders.books[1].quantity)
          console.log(this.orders.books[1].book.price)

        })
    })
    this.calculateCopies();
    this.calculateTotal();
    this.subtotal(this.orders.books);


  }
  calculateCopies() {
    let count: number = 0;

    //this.orders.books.forEach(e => {
      //count = count + e.quantity;
    //});

    for(let i=0;i<this.books.length;i++)
    {
      count=count+this.books[i].quantity;
    }
    console.log(count);
    return count;
  }

  /* calculateSubtotal() {
    let subtotal: number = 0;

    //this.orders.books.forEach(e => {
      //count = count + e.quantity;
    //});

    for(let i=0;i<this.books.length;i++)
    {
      subtotal=subtotal+this.books[i].quantity*this.books[i];
    }
    return subtotal;
  } */
  calculateTotal() {
    let total: number = 0;
    // this.orders.books.forEach(e => {
    //   total = total + e.book.price * e.quantity;
    // });
    for(let i=0;i<this.books.length;i++){
      total=total+this.books[i].quantity*this.books[i].book[i].price;
    }
    console.log("mbmn   "+total);
    return total;
  }

  subtotal(books: OrderedBook) {
    let subtotal: number = 0;
    subtotal = books.book[0].price * books.quantity;
    
    console.log("amber  "+subtotal);
    return subtotal;
  }
  edit() {
    console.log(this.orders.book);
    this.adminService.editOrder(this.orders).subscribe(data => { this.router.navigate['adminOrderList'] });
  }

}
