import { Component, OnInit } from '@angular/core';
import { Order } from '../class/order';
import { AdminService } from '../service/admin.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrls: ['./orderdetails.component.css']
})
export class OrderdetailsComponent implements OnInit {
  orders:Order;

  constructor(private adminService: AdminService, private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>{
      this.adminService.getOrderById(params['id'])
      .subscribe((result)=>{console.log(result);this.orders=result;
        console.log(this.orders.books[1].book.author);
        console.log(this.orders.books[1].book.title)
        console.log(this.orders.books[1].quantity)
        console.log(this.orders.books[1].book.price)
       
      })
    }) 
    
  }
}
