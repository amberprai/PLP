import { Component, OnInit } from '@angular/core';

import { AdminService } from '../service/admin.service';
import { Order, Customer } from '../class/order';
import { OrderDetail } from 'src/app/order-detail';
@Component({
  selector: 'app-orderlisting',
  templateUrl: './orderlisting.component.html',
  styleUrls: ['./orderlisting.component.css']
})
export class OrderlistingComponent implements OnInit {
order:Order[];

  constructor(private adminOrderService:AdminService) { }
  

  ngOnInit() {
        this.adminOrderService.getOrderList().subscribe(data =>{console.log(data);this.order=data})
        //this.adminOrderService.getOrderList1().subscribe(data=>{console.log(data);this.orderDetails=data})
      }

      deleteOrderDetail(list:Order){
        this.adminOrderService.deleteOrder(list).subscribe((data)=>{this.order=this.order.filter(c=>c!==list)});
      }
      }
 
  

