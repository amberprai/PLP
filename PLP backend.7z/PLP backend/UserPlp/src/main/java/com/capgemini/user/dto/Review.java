package com.capgemini.user.dto;
import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
public class Review {
	@Id
	@SequenceGenerator(name = "ID_Gen", sequenceName = "reviewseq", initialValue = 1000, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_Gen")
	private int Id;
	private String Book;
	private int Rating;
	private String Headline;
	private String Customer;
	private Date ReviewOn;

	public Review() {
		super();
		
	}

	public Review(int id, String book, int rating, String headline, String customer, Date reviewOn) {
		super();
		
		Id = id;
		Book = book;
		Rating = rating;
		Headline = headline;
		Customer = customer;
		ReviewOn = reviewOn;
	}

	
	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getBook() {
		return Book;
	}

	public void setBook(String book) {
		Book = book;
	}

	public int getRating() {
		return Rating;
	}

	public void setRating(int rating) {
		Rating = rating;
	}

	public String getHeadline() {
		return Headline;
	}

	public void setHeadline(String headline) {
		Headline = headline;
	}

	public String getCustomer() {
		return Customer;
	}

	public void setCustomer(String customer) {
		Customer = customer;
	}

	public Date getReviewOn() {
		return ReviewOn;
	}

	public void setReviewOn(Date reviewOn) {
		ReviewOn = reviewOn;
	}
}
