import { Component, OnInit } from '@angular/core';
import { Books } from 'src/app/book';
import { UserService } from 'src/app/service/user.service';



@Component({
  selector: 'app-home',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BookListComponent implements OnInit {
  books:Books[];
  constructor(private bookService:UserService) { }

  ngOnInit() {
    this.bookService.getAllBooks().subscribe((data:Books[])=>{this.books=data 
      console.log("all"+this.books)});
  }
  deleteBook(book:Books){
    if(window.confirm("Are you sure you want to delete the user with ID"+book.id)){
    this.bookService.deleteBook(book).subscribe(
      (data)=>{this.books=this.books.filter(c=>c!==book)});
  }
}
}
