import { Component, OnInit } from '@angular/core';


import { Router } from '@angular/router';
import { Books } from 'src/app/book';
import { UserService } from 'src/app/service/user.service';


@Component({
  selector: 'app-createbook',
  templateUrl: './createbook.component.html',
  styleUrls: ['./createbook.component.css']
})
export class CreatebookComponent {

  // book:Books
  bookData:Books={"id":0,"index":0,"category":'',"title":'',"author":'',"isbn":'',"publishedDate":'',"price":0,"description":''};
  constructor(private bookService:UserService,private router:Router) { }

  ngOnInit() {
  }
  createbook(){
    console.log(this.bookData);
    this.bookService.createBook(this.bookData).subscribe(
      (data)=>{this.router.
        navigate(['login/adminhomepage/booklist']);}
    );
  }
  back(){
    this.router.navigate(['login/adminhomepage/booklist']);
  }
  
}
