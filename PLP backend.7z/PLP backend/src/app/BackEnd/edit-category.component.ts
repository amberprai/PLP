import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { Category } from '../category.interface';
import { UserService } from '../service/user.service';


@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.css']
})
export class EditCategoryComponent implements OnInit {
  categoryData:Category={"id":0,"categoryName":''}
  constructor(private categoryService:UserService,private router:Router, private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>{this.categoryService.getCategory(params['id']).subscribe((result)=>{this.categoryData=result;})});
  }
  updateCategory(){
    console.log(this.categoryData.id);
    this.categoryService.updateCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['login/adminhomepage/category']);});
  }
  back(){
    this.router.navigate(['login/adminhomepage/category']);
  }
}
