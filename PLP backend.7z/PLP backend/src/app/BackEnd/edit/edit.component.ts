import { Component, OnInit } from '@angular/core';
import { Userbean } from 'src/app/userbean';
import { UserService } from 'src/app/service/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  userData:Userbean={"id":0,"email":'',"fullName":'',"password":''};
  constructor(private userService:UserService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>{this.userService.getUser(params['id']).subscribe((result)=>{this.userData=result;})})
  }
edit(user:Userbean){
  console.log(this.userData.fullName);
    this.userService.edit(this.userData).subscribe((data)=>{this.router.navigate(['login/adminhomepage/users']);}
    );
  
}
back(){
  this.router.navigate(['login/adminhomepage/users']);
}
}
