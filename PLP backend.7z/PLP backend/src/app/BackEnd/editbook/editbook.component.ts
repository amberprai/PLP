import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { Books } from 'src/app/book';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls: ['./editbook.component.css']
})
export class EditbookComponent{

  bookData:Books={"id":0,"index":0,"category":'',"title":'',"author":'',"isbn":'',"publishedDate":'',"price":0,"description":''};
  constructor( private bookService:UserService, private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{this.bookService.getBook(params['id'])
    .subscribe((result)=>{this.bookData=result;})}
    );
  }
 
  editbook(){
    console.log(this.bookData);
    this.bookService.editBook(this.bookData).subscribe(
      (data)=>{this.router.navigate(['login/adminhomepage/booklist']);}
    );
  }
  back(){
    this.router.navigate(['login/adminhomepage/booklist']);
  }
}
