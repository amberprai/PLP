import { Component, OnInit } from '@angular/core';


import { Router, ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/customer';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {
  customerData:Customer={id:0,email:'',fullname:'',password:'',confirmpassword:'',phonenumber:0,
  address:'',zipcode:0,city:'',country:''};
  constructor(private customerService:UserService, 
private router:Router,private route:ActivatedRoute) { }
  ngOnInit() {
    
    this.route.params.subscribe((params)=>{this.customerService.getCustomer(params['id']).
    subscribe((result)=>{this.customerData=result;})});
  }
       edit(){
    console.log(this.customerData);
    this.customerService.editCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['login/adminhomepage/customerslist']);});
    
  }
  back(){
    this.router.navigate(['login/adminhomepage/customerslist']);
  }

}

