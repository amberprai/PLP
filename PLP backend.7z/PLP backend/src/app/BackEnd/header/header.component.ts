import { Component, OnInit } from '@angular/core';
import { Userbean } from 'src/app/userbean';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
userData:Userbean={"id":0,"email":'',"fullName":'',"password":''}
user:string;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }

}
