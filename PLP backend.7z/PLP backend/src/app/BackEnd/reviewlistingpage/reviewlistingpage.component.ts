import { Component, OnInit } from '@angular/core';
import { Review } from 'src/app/review';
import { UserService } from 'src/app/service/user.service';



@Component({
  selector: 'app-reviewlistingpage',
  templateUrl: './reviewlistingpage.component.html',
  styleUrls: ['./reviewlistingpage.component.css']
})
export class ReviewlistingpageComponent implements OnInit {
  reviews:Review[];
  reviewData:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  constructor(private reviewService:UserService) { }
  
  ngOnInit() {
    this.reviewService.getAllReviews().subscribe((data)=>{this.reviews=data;});
    
   }
   deleteReview(review:Review){
    if(window.confirm("Are you sure you want to delete the review with id "+review.id)){
    this.reviewService.deleteReview(review).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
   }
   }
  }
 
 