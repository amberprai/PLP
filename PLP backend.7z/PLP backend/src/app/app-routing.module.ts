import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './BackEnd/show/show.component';

import { CreateComponent } from './BackEnd/create/create.component';
import { EditComponent } from './BackEnd/edit/edit.component';
import { HomepageComponent } from './BackEnd/homepage/homepage.component';
import { LoginpageComponent } from './BackEnd/loginpage/loginpage.component';
import { AdminhomepageComponent } from './BackEnd/adminhomepage/adminhomepage.component';
import { CustomermanagementComponent } from './BackEnd/customermanagement/customermanagement.component';
import { CreatecustomerComponent } from './BackEnd/createcustomer/createcustomer.component';
import { EditcustomerComponent } from './BackEnd/editcustomer/editcustomer.component';
import { CategorylistComponent } from './BackEnd/categorylist.component';
import { AddCategoryComponent } from './BackEnd/add-category.component';
import { EditCategoryComponent } from './BackEnd/edit-category.component';
import { ReviewlistingpageComponent } from './BackEnd/reviewlistingpage/reviewlistingpage.component';
import { EditreviewComponent } from './BackEnd/editreview/editreview.component';
import { BookListComponent } from './BackEnd/Booklist/booklist.component';
import { CreatebookComponent } from './BackEnd/createbook/createbook.component';
import { EditbookComponent } from './BackEnd/editbook/editbook.component';


const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'login',component:LoginpageComponent},
  {path:'login/adminhomepage',component:AdminhomepageComponent},
  {path:'login/adminhomepage/users',component:ShowComponent},
  {path:'login/adminhomepage/users/createuser',component:CreateComponent},
  {path:'login/adminhomepage/users/edituser/:id',component:EditComponent},
  {path:'login/adminhomepage/newuser',component:CreateComponent},
  {path:'login/adminhomepage/customerslist',component:CustomermanagementComponent},
  {path:'login/adminhomepage/customerslist/create',component:CreatecustomerComponent},
  {path:'login/adminhomepage/users/customerslist',component:CustomermanagementComponent},
  {path:'login/adminhomepage/users/customerslist/create',component:CreatecustomerComponent},
  {path:'login/adminhomepage/customerslist/edit/:id',component:EditcustomerComponent},
  {path:'login/adminhomepage/users/customerslist/edit/:id',component:EditcustomerComponent},
  {path:'login/adminhomepage/category',component:CategorylistComponent},
  {path:'login/adminhomepage/users/category',component:CategorylistComponent},
  {path:'login/adminhomepage/category/add',component:AddCategoryComponent},
  {path:'login/adminhomepage/users/category/add',component:AddCategoryComponent},
  {path:'login/adminhomepage/category/edit/:id',component:EditCategoryComponent},
  {path:'login/adminhomepage/users/category/edit/:id',component:EditCategoryComponent},
  {path:'login/adminhomepage/category/users',component:ShowComponent},
  {path:'login/adminhomepage/category/users/category',component:CategorylistComponent},
  {path:'login/adminhomepage/category/users/category/add',component:AddCategoryComponent},
  {path:'login/adminhomepage/newcustomer',component:CreatecustomerComponent},
  {path:'login/adminhomepage/newcategory',component:AddCategoryComponent},
  {path:'login/adminhomepage/reviewlist',component:ReviewlistingpageComponent},
  {path:'login/adminhomepage/reviewlist/editreview/:id',component:EditreviewComponent},
  {path:'login/adminhomepage/booklist',component:BookListComponent},
  {path:'login/adminhomepage/booklist/create',component:CreatebookComponent},
  {path:'login/adminhomepage/booklist/edit/:id',component:EditbookComponent},
  {path:'login/adminhomepage/newbook',component:CreatebookComponent},

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
