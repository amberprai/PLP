export  class Books{
    id:number;
    index:number;
    title: string;
    author: string;
    category: string;
    isbn: string;
    price: number;
    publishedDate: string;
    description: string;
}