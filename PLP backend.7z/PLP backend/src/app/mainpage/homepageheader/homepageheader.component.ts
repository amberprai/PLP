import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepageheader',
  templateUrl: './homepageheader.component.html',
  styleUrls: ['./homepageheader.component.css']
})
export class HomepageheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
