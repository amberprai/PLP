import { Injectable } from '@angular/core';
import { Userbean } from '../userbean';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../customer';
import { Category } from '../category.interface';
import { Review } from '../review';
import { Books } from '../book';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string="http://localhost:3000";
  filtereddata:Userbean={"id":0,"email":'',"fullName":'',"password":''};

  constructor(private http:HttpClient) { }
  ngOnInit(){

  }
  getData(){
    return this.http.get<Userbean[]>(this.url);
  }
 
  getUser(id:number){
    return this.http.get<Userbean>(this.url+"/users/"+id);
 }
  deleteUser(users:Userbean){
    
   return this.http.delete<Userbean[]>(this.url+"/users/"+users.id);
  }
  addUser(user:Userbean): Observable<Userbean[]> {
    
    return this.http.post<Userbean[]>(this.url+"/addUsers", user);
  }
  edit(user:Userbean){
    return this.http.put(this.url+"/users/"+user.id,user);
  }
  getLoginEmail(user:Userbean):Observable<Userbean>{
   
    return this.http.get<Userbean>(this.url+"/usersemail/"+user.email);
  }
  public createCustomer(customer: Customer){
    console.log(customer);
    return this.http.post<Customer>(this.url+"/customers", customer);
  }
 getAllCustomers(){
 return this.http.get<Customer[]>(this.url+"/customers/");
 }
 deleteCustomer(customer: Customer){
 return this.http.delete<Customer[]>(this.url+"/customers/"+customer.id);
 }
 getCustomer(id: number){
  return this.http.get<Customer>(this.url+"/customers/"+id);
}
 editCustomer(customer: Customer){              
   return this.http.put(this.url+"/customers/"+customer.id,customer);
 }
 addCategory(category:Category){
  return this.http.post<Category>(this.url+"/addcategory",category);
}
getAllCategories(){
  return this.http.get<Category[]>(this.url+"/category");
}
deleteCategory(category:Category){
  return this.http.delete<Category[]>(this.url+"/category/"+category.id);
}
updateCategory(category:Category){
  return this.http.put(this.url+"/category/"+category.id,category);
}
getCategory(id:number){
  console.log(id);
  return this.http.get<Category>(this.url+"/getcat/"+id);
}
public getAllReviews(){
  return this.http.get<Review[]>(this.url+'/reviews');
}

getReview(id:number){
  return this.http.get<Review>(this.url+"/reviews/"+id);
}
editReview(review:Review){
  return this.http.put(this.url+"/reviews/"+review.id,review);
}

deleteReview(review:Review){
  console.log(review);
  return this.http.delete<Review[]>(this.url+"/reviews/"+review.id);
}

public getAllBooks(){
  return this.http.get<Books[]>(this.url+"/books");
}
public createBook(book: Books) {
  return this.http.post<Books>(this.url+"/books", book);
}
public editBook(book: Books){
 return this.http.put<Books>(this.url+"/books/"+book.id,book);
}
deleteBook(book:Books){
  return this.http.delete<Books[]>(this.url+"/books/"+book.id);
}
getBook(id:number){
  return this.http.get<Books>(this.url+"/books/"+id);
}
}
