package com.capgemini.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserPlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserPlpApplication.class, args);
	}

}
