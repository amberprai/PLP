package com.capgemini.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.user.dto.Category;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.dto.UserBean;
import com.capgemini.user.exception.UserException;
import com.capgemini.user.service.UserService;


@CrossOrigin("http://localhost:4200")
@RestController
public class UserController {
@Autowired
private UserService userService;
@Autowired
private UserService custService;
@Autowired
private UserService catgService;

@GetMapping()

public List<UserBean> getAllUsers() throws UserException {
return userService.getAllUsers();

}
@PostMapping("/addUsers")
public List<UserBean> addUsers(@RequestBody UserBean user) throws UserException {
	return userService.addUsers(user);
	
	
}
@DeleteMapping("/users/{id}")
public List<UserBean> deleteUser(@PathVariable int id) throws UserException {
	return userService.deleteUser(id);
	
}
@PutMapping("/users/{id}")
public List<UserBean> updateUser(@PathVariable int id, @RequestBody UserBean user) throws UserException {
	return userService.updateUser(id, user);
	
}
@ExceptionHandler(Exception.class)
public ResponseEntity<String> handleErrors(Exception ex) {
	return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	
}
@GetMapping("/users/{id}")
public UserBean getById(@PathVariable int id) throws UserException {
	return userService.getById(id);
	
}
@GetMapping("/usersemail/{email}")
public UserBean getUserByEmail(@PathVariable String email)throws UserException{
	return userService.getUserByEmail(email);
	
}
@GetMapping("/customers")
public List<Customer> showAllCustomers() throws UserException
{
	 return custService.showAllCustomers();
}
@PostMapping("/customers")
public List<Customer> createCustomer(@RequestBody Customer customer)throws UserException{
	return custService.createCustomer(customer);

}
@DeleteMapping("/customers/{id}")
public List<Customer> deleteCustomer(@PathVariable int id)throws UserException{
	return custService.deleteCustomer(id);
}
@GetMapping("/customers/{id}")
   public Customer getCustomerById(@PathVariable int id) throws UserException {
       return custService.getCustomerById(id);
   }
@PutMapping("/customers/{id}")
public List<Customer>  editCustomer(@PathVariable int id,@RequestBody Customer customer) throws UserException {
     return  custService.editCustomer(id,customer);

}

@GetMapping("/category")
public List<Category> getAllCategories() throws UserException{
	return catgService.getAllCategories();
}
@PostMapping("/addcategory")
public List<Category> addCategory(@RequestBody Category category) throws UserException{
	return catgService.addCategory(category);
}
@DeleteMapping("/category/{id}")
public List<Category> deleteCategory(@PathVariable int id) throws UserException{
	return catgService.deleteCategory(id);
}
@PutMapping("/category/{id}")
public List<Category> updateCategory(@PathVariable int id,@RequestBody Category category) throws UserException{
	return catgService.updateCategory(id,category);
}
@GetMapping("/getcat/{id}")
public Category getByid(@PathVariable int id) throws UserException
{
	return catgService.getByid(id);
}

}
