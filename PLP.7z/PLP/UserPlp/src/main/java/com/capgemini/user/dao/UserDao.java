package com.capgemini.user.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.user.dto.UserBean;

@Repository
public interface UserDao extends JpaRepository<UserBean, Integer>{
@Query("from UserBean where email=:email")
UserBean getUserByEmail(@Param ("email") String email);


}
