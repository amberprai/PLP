package com.capgemini.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.dao.CategoryRepository;
import com.capgemini.user.dao.CustomerRepository;
import com.capgemini.user.dao.UserDao;
import com.capgemini.user.dto.Category;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.dto.UserBean;
import com.capgemini.user.exception.UserException;



@Service
public class UserServiceImpl implements UserService{
@Autowired
private UserDao dao;
@Autowired
private CustomerRepository custdao;
@Autowired
private CategoryRepository catgdao;
	

	@Override
	public List<UserBean> getAllUsers() throws UserException {
		
		try {
			return dao.findAll();
		} catch (Exception e) {
			
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<UserBean> addUsers(UserBean user) throws UserException {
		try {
			dao.save(user);
			return getAllUsers();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<UserBean> deleteUser(int id) throws UserException {
		
		if(dao.existsById(id))
		{
			dao.deleteById(id);
			return getAllUsers();
		}
		else {
			throw new UserException("Cannot delete");
		}
		
	}
	

	@Override
	public List<UserBean> updateUser(int id, UserBean user) throws UserException {
		
		if(dao.existsById(id))
		{
			dao.save(user);
			return getAllUsers();
		}
		else {
			throw new UserException("Cannot find ");
			
		}
	}

	@Override
	public UserBean getById(int id) throws UserException {
		
		try {
			Optional<UserBean> data= dao.findById(id);
			if(data.isPresent())
			{
				return data.get();
			}
			else {
				throw new UserException("Employee with Id "+id+"does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public UserBean getUserByEmail(String email) throws UserException {
		
		return dao.getUserByEmail(email);
	}

	@Override
	public List<Customer> createCustomer(Customer customer) throws UserException {
		
		try {
			
			custdao.save(customer);
			return showAllCustomers();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}

	}

	@Override
	public List<Customer> editCustomer(int id,Customer customer) throws UserException {
		if (custdao.existsById(id)) {
			custdao.save(customer);

			return showAllCustomers();
		} else {
			throw new UserException("Invalid customer cannot be updated");
		}
	}

	@Override
	public List<Customer> deleteCustomer(int id) throws UserException {
		
		if (custdao.existsById(id)) {
			custdao.deleteById(id);
			return showAllCustomers();
		} else {
			throw new UserException("Cannot delete customer with id " + id + " does not exist");
		}
	}

	@Override
	public List<Customer> showAllCustomers() throws UserException {
		try {
			return custdao.findAll();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public Customer getCustomerById(int id) throws UserException {
		try {
            Optional<Customer> data=custdao.findById(id);
            if(data.isPresent()) {
                return data.get();
            }
            else {
                throw new UserException("Product with id "+id+" does not exist");
            }
        } catch (Exception e ) {
            throw new UserException(e.getMessage());
        
        
            }
        }

	@Override
	public List<Category> getAllCategories() throws UserException {
		return catgdao.findAll();
		
	}

	@Override
	public List<Category> addCategory(Category category) throws UserException {
		catgdao.save(category);
		return getAllCategories();
	}

	@Override
	public List<Category> updateCategory(int id, Category category) throws UserException {
		if(catgdao.existsById(id)) {
			catgdao.save(category);
			}
			return getAllCategories();
	}

	@Override
	public List<Category> deleteCategory(int id) throws UserException {
		catgdao.deleteById(id);
		return getAllCategories();
	}

	@Override
	public Category getByid(int id) throws UserException {
		return catgdao.findById(id).get();
	}

	}


