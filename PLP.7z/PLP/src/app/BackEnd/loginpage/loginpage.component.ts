import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { Userbean } from 'src/app/userbean';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  userData:Userbean={"id":0,"email":'',"fullName":'',"password":''};
  loginData:Userbean;
  
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
  }
login(){
  console.log(this.userData);
  this.userService.getLoginEmail(this.userData).subscribe(data=>this.loginData=data)
  if(this.loginData!=null){
    this.router.navigate(['login/adminhomepage']);

  }else{
alert("Invalid Login Credentials")
  }
}
}
