import { Component, OnInit } from '@angular/core';
import { Userbean } from 'src/app/userbean';
import { UserService } from 'src/app/service/user.service';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  

users:Userbean[];
  constructor(private userService:UserService) { }

  ngOnInit() {
    
    this.userService.getData().subscribe((data:Userbean[])=>{this.users=data;
     });
  }
  delete(user:Userbean){
    if(window.confirm("Are you sure you want to delete the user with ID"+user.id)){
  this.userService.deleteUser(user).subscribe((data)=>{this.users=this.users.filter(c=>c!==user)});
  }
  }
  
}
