import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Validators } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowComponent } from './BackEnd/show/show.component';
import { CreateComponent } from './BackEnd/create/create.component';
import { EditComponent } from './BackEnd/edit/edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './service/user.service';
import { HeaderComponent } from './BackEnd/header/header.component';
import { FooterComponent } from './BackEnd/footer/footer.component';
import { HomepageComponent } from './BackEnd/homepage/homepage.component';
import { HomepageheaderComponent } from './mainpage/homepageheader/homepageheader.component';
import { HomepagefooterComponent } from './mainpage/homepagefooter/homepagefooter.component';
import { LoginpageComponent } from './BackEnd/loginpage/loginpage.component';
import { AdminhomepageComponent } from './BackEnd/adminhomepage/adminhomepage.component';
import { CreatecustomerComponent } from './BackEnd/createcustomer/createcustomer.component';
import { EditcustomerComponent } from './BackEnd/editcustomer/editcustomer.component';
import { CustomermanagementComponent } from './BackEnd/customermanagement/customermanagement.component';
import { AddCategoryComponent } from './BackEnd/add-category.component';
import { CategorylistComponent } from './BackEnd/categorylist.component';
import { EditCategoryComponent } from './BackEnd/edit-category.component';
import { WelcomeComponent } from './BackEnd/welcome.component';

@NgModule({
  declarations: [
    AppComponent,
    ShowComponent,
    CreateComponent,
    EditComponent,
    HeaderComponent,
    FooterComponent,
    HomepageComponent,
    HomepageheaderComponent,
    HomepagefooterComponent,
    LoginpageComponent,
    AdminhomepageComponent,
    CreatecustomerComponent,
    EditcustomerComponent,
    CustomermanagementComponent,
    AddCategoryComponent,
    CategorylistComponent,
    EditCategoryComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    ReactiveFormsModule, 
    HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
