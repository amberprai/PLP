export class Customer {
    id: number;
    email:string;
    fullname:string;
    password:string;
    confirmpassword:string;
    phonenumber:number;
    address:string;
    city:string;
    zipcode:number;
    country:string;
    
    constructor(id: number,email:string, fullname:string, password:string, confirmpassword:string,phonenumber:number,
        address:string,
        city:string,
        zipcode:number,
        country:string) {
        this.id = id;
        this.email = email;
        this.fullname = fullname;
        this.password = password;
        this.confirmpassword = confirmpassword;
        this.phonenumber=phonenumber;
        this.address=address;
        this.city=city;
        this.zipcode=zipcode;
        this.country=country
      }
}