import { Injectable } from '@angular/core';
import { Userbean } from '../userbean';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../customer';
import { Category } from '../category.interface';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string="http://localhost:3000";

  constructor(private http:HttpClient) { }
  ngOnInit(){

  }
  getData(){
    return this.http.get<Userbean[]>(this.url);
  }
 
  getUser(id:number){
    return this.http.get<Userbean>(this.url+"/users/"+id);
 }
  deleteUser(users:Userbean){
    
   return this.http.delete<Userbean[]>(this.url+"/users/"+users.id);
  }
  addUser(user:Userbean): Observable<Userbean[]> {
    
    return this.http.post<Userbean[]>(this.url+"/addUsers", user);
  }
  edit(user:Userbean){
    return this.http.put(this.url+"/users/"+user.id,user);
  }
  getLoginEmail(user:Userbean):Observable<Userbean>{
   
    return this.http.get<Userbean>(this.url+"/usersemail/"+user.email);
  }
  public createCustomer(customer: Customer){
    console.log(customer);
    return this.http.post<Customer>(this.url+"/customers", customer);
  }
 getAllCustomers(){
 return this.http.get<Customer[]>(this.url+"/customers/");
 }
 deleteCustomer(customer: Customer){
 return this.http.delete<Customer[]>(this.url+"/customers/"+customer.id);
 }
 getCustomer(id: number){
  return this.http.get<Customer>(this.url+"/customers/"+id);
}
 editCustomer(customer: Customer){              
   return this.http.put(this.url+"/customers/"+customer.id,customer);
 }
 addCategory(category:Category){
  return this.http.post<Category>(this.url+"/addcategory",category);
}
getAllCategories(){
  return this.http.get<Category[]>(this.url+"/category");
}
deleteCategory(category:Category){
  return this.http.delete<Category[]>(this.url+"/category/"+category.id);
}
updateCategory(category:Category){
  return this.http.put(this.url+"/category/"+category.id,category);
}
getCategory(id:number){
  console.log(id);
  return this.http.get<Category>(this.url+"/getcat/"+id);
}
}
