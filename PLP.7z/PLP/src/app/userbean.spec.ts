import { Userbean } from './userbean';

describe('Userbean', () => {
  it('should create an instance', () => {
    expect(new Userbean()).toBeTruthy();
  });
});
