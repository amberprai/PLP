package com.example.demo.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BookStore_Category")
public class Category {

	@Id
	@GeneratedValue
	private int id;
	private String categoryName;
	
}
