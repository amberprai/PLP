package com.example.demo.beans;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BookStore_OrderedBook")
public class OrderedBook {

	@Id
	private int id;
	@ManyToOne
	private Book book;
	private Integer quantity;
}
