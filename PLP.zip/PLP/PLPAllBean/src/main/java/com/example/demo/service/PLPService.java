package com.example.demo.service;

import java.util.List;

import com.example.demo.beans.Order;

public interface PLPService {

	List<Order> getAllOrders();
	Order getOrderbyId(int id);
}
