package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.beans.Order;
import com.example.demo.dao.OrderRepo;

@Service
public class PLPServiceImpl implements PLPService {

	@Autowired
	private OrderRepo orderdao;
	
	@Override
	public List<Order> getAllOrders() {
		
		return orderdao.findAll();
	}

	@Override
	public Order getOrderbyId(int id) {
		
		return orderdao.findById(id).get();
	}

}
