import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderHistoryComponent } from './order/frontend/order-history/order-history.component';
import { OrderDetailComponent } from './order/frontend/order-detail/order-detail.component';
import { ShoppingCartComponent } from './order/frontend/shopping-cart/shopping-cart.component';
import { CartCheckoutComponent } from './order/frontend/cart-checkout/cart-checkout.component';
import { OrderlistingComponent } from './order/backend/orderlisting/orderlisting.component';
import { OrderdetailsComponent } from './order/backend/orderdetails/orderdetails.component';
import { EditorderComponent } from './order/backend/editorder/editorder.component';



const routes: Routes = [
  {path:'',component:OrderHistoryComponent},
  {path:'orderList',component:OrderHistoryComponent},
  {path:'orderDetail',component:OrderDetailComponent},
  {path:'shoppingCart',component:ShoppingCartComponent},
  {path:'cartCheckout',component:CartCheckoutComponent},
  {path:'admin/orderList',component:OrderlistingComponent},
 {path:'adminOrderDetails',component:OrderlistingComponent},
 {path:'admin/editOrder',component:EditorderComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
