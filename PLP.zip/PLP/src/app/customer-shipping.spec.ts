import { CustomerShipping } from './customer-shipping';

describe('CustomerShipping', () => {
  it('should create an instance', () => {
    expect(new CustomerShipping()).toBeTruthy();
  });
});
