import { Component, OnInit } from '@angular/core';
import{Adminorder} from '../class/adminorder'
import { AdminService } from '../service/admin.service';
@Component({
  selector: 'app-orderlisting',
  templateUrl: './orderlisting.component.html',
  styleUrls: ['./orderlisting.component.css']
})
export class OrderlistingComponent implements OnInit {
orderList:Adminorder[];
  constructor(private adminOrderService:AdminService) { }
  

  ngOnInit() {
  }
  getOrderList()
  {  console.log(this.orderList);
      this.adminOrderService.getOrderList().subscribe(data =>{
        if(data!=null)
        {
          this.orderList=data;
        }
      })
    }
  
}
