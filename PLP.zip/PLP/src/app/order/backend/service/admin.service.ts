import { Injectable } from '@angular/core';
import { Adminorder } from '../class/adminorder'
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
 
orders:Adminorder[];
order:Adminorder;
url1:string="http://localhost:4000";
  constructor(private http:HttpClient) {
    this.getOrder().subscribe(data=>this.orders=data);
}
getOrder():Observable<Adminorder[]> {
  return this.http.get<Adminorder[]>(this.url1);
}
getData(){
  return this.orders;
}
setOrder(orders:Adminorder[])
  {
    this.orders=orders;
  }
  public getOrderList() {
    return this.http.get<Adminorder[]>(this.url1+'/adminOrderDetails')
    
  }
}