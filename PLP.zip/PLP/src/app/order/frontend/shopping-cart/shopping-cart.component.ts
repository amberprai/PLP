import { Component, OnInit } from '@angular/core';
import {  ShoppingCart } from 'app/orderhistory';
import { OrderServiceService } from 'app/order/order.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
shoppingCart:ShoppingCart[];
  constructor(private orderService:OrderServiceService) { }

  ngOnInit() {
    if(!this.orderService.getCartData()){
      this.orderService.getCartDetails().subscribe(data=>{
        this.shoppingCart=data;
        this.orderService.setCartData(this.shoppingCart);
      });
  }
  }
}
