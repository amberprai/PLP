export class Orderhistory {
    img:string;
    book:string;
    author:string;
    price:number;
    quantity:number;
    subtotal:number;
    total:number;
}

export class ShoppingCart {
    img:string;
    book:string;
    price:number;
    quantity:number;
    subtotal:number;
    total:number;
}


