package com.example.demo.exception;

public class PLPException extends Exception {

	public PLPException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PLPException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PLPException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PLPException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PLPException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
