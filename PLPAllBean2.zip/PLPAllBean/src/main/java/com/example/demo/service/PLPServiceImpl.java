package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.beans.Order;
import com.example.demo.beans.OrderedBook;
import com.example.demo.dao.OrderRepo;
import com.example.demo.dao.OrdererBookRepo;;

@Service
public class PLPServiceImpl implements PLPService {

	@Autowired
	private OrderRepo orderdao;

//	private OrdererBookRepo  

	@Override
	public List<Order> getAllOrders() {

		return orderdao.findAll();
	}

	@Override
	public Order getOrderbyId(int id) {

		return orderdao.findById(id).get();
	}

	@Override
	public void delete(int id) {
		orderdao.deleteById(id);
	}

	@Override
	public void edit(int id) {
		Order order = orderdao.findById(id).get();
		if (order != null) {
			orderdao.save(order);
		}

	}

	@Override
	public Order getOrder(int id) {
	
		return orderdao.findById(id).get();
	}

}
