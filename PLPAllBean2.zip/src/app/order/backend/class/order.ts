export class Order {
    id: number;
    orderedBy: string;
    paymentMethod: string;
    status: string;
    orderDate: string;
    recipientName: string;
    recipientPhone: string;
    shipto: string;
    book: String;
    customer: String;

    constructor(id: number, orderedBy: string, paymentMethod: string, status: string, orderDate: string, recipientName: string, recipientPhone: string, shipto: string, book: string, customer: string) {
        this.id = id;
        this.orderedBy = orderedBy;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.orderDate = orderDate;
        this.recipientName = recipientName;
        this.recipientPhone = recipientPhone;
        this.shipto = shipto;
        this.book = book;
        this.customer = customer;
    }
}

export class OrderedBook {
    id: number;
    books: Book;
    quantity: number;

    constructor(id: number, books: Book, quantity: number) {
        this.id = id;
        this.books = books;
        this.quantity = quantity;
    }
}

export class Book {
    id: number;
    category: Category;
    title: string;
    author: string;
    isbn: string;
    purchaseDate: string;
    bookImage: string;
    price: number;
    description: string;
    reviews: Review;

    constructor(id: number, category: Category, title: string, author: string, isbn: string, purchaseDate: string, bookImage: string, price: number, description: string, review: Review) {
        this.id = id;
        this.category = category;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.purchaseDate = purchaseDate;
        this.bookImage = bookImage;
        this.price = price;
        this.description = description;
        this.reviews = review;
    }

}

export class Customer {
    id: number;
    email: string;
    fullname: string;
    password: string;
    phonenumber: string;
    address: string;
    city: string;
    country: string;
    zipcode: string;
    registerDate: string;
    orders: Order;

    constructor(id: number, email: string, fullname: string, password: string, phonenumber: string, address: string, city: string, country: string, zipcode: string, registerDate: string, orders: Order) {
        this.id = id;
        this.email = email;
        this.fullname = fullname;
        this.password = password;
        this.address = address;
        this.city = city;
        this.country = country;
        this.zipcode = zipcode;
        this.registerDate = registerDate;
        this.orders = orders;

    }
}

export class Review {
    id: number;
    bookTitle: string;
    rating: number;
    customerName: string;
    headline: string;
    comments: string;
    reviewDate: string;

    constructor(id: number, bookTitle: string, rating: number, customerName: string, headline: string, comments: string, reviewDate: string) {
        this.id = id;
        this.bookTitle = bookTitle;
        this.rating = rating;
        this.customerName = customerName;
        this.headline = headline;
        this.comments = comments;
        this.reviewDate = reviewDate;
    }
}

export class Category {
    id: number;
    categoryName: string;

    constructor(id: number, categoryName: string) {
        this.id = id;
        this.categoryName = categoryName;
    }
}
export class User {
    id: number;
    fullName: string;
    email: string;
    password: string;

    constructor(id: number, fullName: string, email: string, password: string) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
    }
}
