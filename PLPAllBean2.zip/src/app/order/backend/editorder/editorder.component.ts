import { Component, OnInit } from '@angular/core';
import { Order, Book, OrderedBook } from '../class/order';
import { AdminService } from '../service/admin.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {
order:Order={"id":0,"book":'',"customer":'',"orderDate":'',"orderedBy":'',"paymentMethod":'',"recipientName":'',"recipientPhone":'',"shipto":'',"status":''};
book:Book;
orderedBook:OrderedBook;






  constructor(private adminService: AdminService, private router:Router,private route:ActivatedRoute) {
   }

  ngOnInit() {
    this.route.params.subscribe((params)=>{
      this.adminService.getOrderById(params['id'])
      .subscribe((result)=>{console.log(result);this.order=result;})
    })
  }
  edit(){
    this.adminService.editOrder(this.order).subscribe(data=>{this.router.navigate['']});
  }

}
