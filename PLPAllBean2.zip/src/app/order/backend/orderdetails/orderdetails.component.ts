import { Component, OnInit } from '@angular/core';
import { Order } from '../class/order';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrls: ['./orderdetails.component.css']
})
export class OrderdetailsComponent implements OnInit {
order:Order[];

  constructor() { }

  ngOnInit() {
  }

}
