import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Order } from '../class/order';
import { OrderDetail } from 'src/app/order-detail';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  orders: Order[];
  orderDetails: OrderDetail[];

  url1: string = "http://localhost:4000";
  constructor(private http: HttpClient) {
    this.getOrder().subscribe(data => this.orders = data);
  }
  getOrder(): Observable<Order[]> {
    return this.http.get<Order[]>(this.url1);
  }
  getData() {
    return this.orders;
  }
  setOrder(orders: Order[]) {
    this.orders = orders;
  }
  public getOrderList() {
    return this.http.get<Order[]>(this.url1 + "/adminOrderList");
  }
  public getOrderList1() {
    return this.http.get<OrderDetail[]>(this.url1 + "/adminOrderList");
  }
  deleteOrder(list: Order) {
    console.log(list);
    return this.http.delete<Order[]>(this.url1 + "/delete/" + list.id);
  }

  getOrderById(id:number){
    console.log(id);
    return this.http.get<Order>(this.url1+"/order/"+id);
  }

  editOrder(order:Order)
  {
    return this.http.put(this.url1+"/edit/"+order.id,order);
  }
}