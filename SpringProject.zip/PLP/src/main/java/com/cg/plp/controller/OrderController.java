package com.cg.plp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.plp.dto.Order;
import com.cg.plp.exception.OrderException;
import com.cg.plp.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	private OrderService orderService;

	@GetMapping("/adminOrderList")
	private List<Order> getAllorders() throws OrderException {
		return orderService.getallOrdersList();
	}
}
