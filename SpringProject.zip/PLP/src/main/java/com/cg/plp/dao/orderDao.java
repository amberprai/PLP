package com.cg.plp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.plp.dto.Order;

@Repository
public interface orderDao extends JpaRepository<Order, Integer>{

}
