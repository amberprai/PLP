package com.cg.plp.service;

import java.util.List;

import com.cg.plp.dto.Order;

public interface OrderService {

	List<Order> getallOrdersList();

	Order getOrderById(int id);
}
