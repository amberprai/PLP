package com.cg.plp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.plp.dao.orderDao;
import com.cg.plp.dto.Order;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private orderDao dao;
	@Override
	public List<Order> getallOrdersList() {
	
		return dao.findAll();
	}

	@Override
	public Order getOrderById(int id) {
		
		return dao.findById(id).get();
	}

}
