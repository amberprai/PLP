import { Component, OnInit } from '@angular/core';

import { OrderServiceService } from '../../order.service';
import { OrderDetail } from 'src/app/order-detail';


@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orders:OrderDetail[];
  order:OrderDetail;

  constructor(private orderService:OrderServiceService) { }

  ngOnInit() {
    if(!this.orderService.getData()){
      this.orderService.getOrder().subscribe(data=>{
        this.orders=data;
        this.orderService.setOrder(this.orders);
      });
    }
  }

}
