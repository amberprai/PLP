export class Order {
    id:number;
    orderedBy:string;
    paymentMethod:number;
    status:string;
    orderDate:string;
    recipientName:string;
    recipientPhone:string;
    shipto:string;
    book:Book;
    customer:Customer;
}


export class OrderedBook{
    id:number;
    books:Book;
    quantity:number;
}

export class Book{
 id:number;
 category:Category;
 title:string;
 author:string;
 isbn:string;
 purchaseDate:string;
 bookImage:string;
 price:number;
 description:string;
 reviews:Review; 
}

export class Customer{
    id:number;
    email:string;
    fullname:string;
    password:string;
    phonenumber:string;
    address:string;
    city:string;
    country:string;
    zipcode:string;
    registerDate:string;
    orders:Order;
}

export class Review{
    id:number;
    bookTitle:string;
    rating:number;
    customerName:string;
    headline:string;
    comments:string;
    reviewDate:string;
}

export class Category{
    id:number;
    categoryName:string;
}
